const ExportTextContainer = require('./export-text-container.component')
module.exports = ExportTextContainer
