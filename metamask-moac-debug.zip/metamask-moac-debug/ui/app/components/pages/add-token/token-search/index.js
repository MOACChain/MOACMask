import TokenSearch from './token-search.component'
module.exports = TokenSearch
