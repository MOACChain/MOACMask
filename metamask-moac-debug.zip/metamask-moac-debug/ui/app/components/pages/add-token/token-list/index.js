import TokenList from './token-list.container'
module.exports = TokenList
