import TokenListPlaceholder from './token-list-placeholder.component'
module.exports = TokenListPlaceholder
