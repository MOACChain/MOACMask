import AddToken from './add-token.container'
module.exports = AddToken
