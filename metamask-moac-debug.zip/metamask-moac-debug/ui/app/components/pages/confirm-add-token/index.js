import ConfirmAddToken from './confirm-add-token.container'
module.exports = ConfirmAddToken
