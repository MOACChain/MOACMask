import TokenBalance from './token-balance.container'
module.exports = TokenBalance
