export { default } from './page-container.component'
