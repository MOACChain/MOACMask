export { default } from './page-container-footer.component'
