const Modal = require('./modal')

module.exports = {
  Modal,
}
