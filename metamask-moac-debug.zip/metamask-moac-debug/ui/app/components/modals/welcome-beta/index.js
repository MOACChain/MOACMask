import WelcomeBeta from './welcome-beta.component'
module.exports = WelcomeBeta
