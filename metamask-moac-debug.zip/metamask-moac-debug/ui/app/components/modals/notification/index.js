import Notification from './notification.container'
module.exports = Notification
