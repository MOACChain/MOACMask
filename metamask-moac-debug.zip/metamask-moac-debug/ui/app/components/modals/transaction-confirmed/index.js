import TransactionConfirmed from './transaction-confirmed.component'
module.exports = TransactionConfirmed
