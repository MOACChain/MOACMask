import ConfirmResetAccount from './confirm-reset-account.container'
module.exports = ConfirmResetAccount
