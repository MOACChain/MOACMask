import AppHeader from './app-header.container'
module.exports = AppHeader
