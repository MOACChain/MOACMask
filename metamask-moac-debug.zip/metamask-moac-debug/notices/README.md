# Notices

Those notices are of legal nature. They are displayed to the users of MetaMask.

Any changes or additions must be reviewed by the product management.