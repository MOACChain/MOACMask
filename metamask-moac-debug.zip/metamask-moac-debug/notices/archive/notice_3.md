Please take a moment to [back up your seed phrase again](http://www.moacdapp.io/).

MetaMask has become aware of a previous issue where a very small number of users were shown the wrong seed phrase to back up. The only way to protect yourself from this issue, is to back up your seed phrase again now.

You can follow the guide at this link:

[http://www.moacdapp.io/](http://www.moacdapp.io/)

We have fixed the known issue, but will be issuing ongoing bug bounties to help prevent this kind of problem in the future.

For more information on this issue, [see this blog post](http://www.moacdapp.io/)
